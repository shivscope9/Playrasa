import { Drama } from "./types";

const sampleVideo =
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";

export const dramas: Drama[] = [
  {
    id: "secret-heir",
    title: "The Secret Heir",
    subtitle: "A driver discovers the family that abandoned him now needs his help.",
    genre: "Revenge",
    poster: "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=600",
    banner: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=1200",
    score: 9.7,
    views: "82.4M",
    episodes: Array.from({ length: 24 }, (_, index) => ({
      id: `secret-heir-${index + 1}`,
      number: index + 1,
      title: index < 3 ? "Free Episode" : "Premium Episode",
      locked: index > 5,
      duration: "1:38",
      videoUrl: sampleVideo
    }))
  },
  {
    id: "midnight-contract",
    title: "Midnight Contract",
    subtitle: "A fake marriage becomes a dangerous alliance.",
    genre: "Romance",
    poster: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=600",
    banner: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=1200",
    score: 9.5,
    views: "51.8M",
    episodes: Array.from({ length: 18 }, (_, index) => ({
      id: `midnight-contract-${index + 1}`,
      number: index + 1,
      title: index < 4 ? "Free Episode" : "VIP Episode",
      locked: index > 7,
      duration: "1:12",
      videoUrl: sampleVideo
    }))
  },
  {
    id: "last-queen",
    title: "The Last Queen",
    subtitle: "A fallen CEO returns with a sharper crown.",
    genre: "Drama",
    poster: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=600",
    banner: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1200",
    score: 9.3,
    views: "39.2M",
    episodes: Array.from({ length: 30 }, (_, index) => ({
      id: `last-queen-${index + 1}`,
      number: index + 1,
      title: index < 5 ? "Free Episode" : "Unlock with Coins",
      locked: index > 9,
      duration: "1:45",
      videoUrl: sampleVideo
    }))
  }
];

export const categories = ["For You", "Romance", "Revenge", "CEO", "Fantasy", "New", "Free"];

export const rewardTasks = [
  { id: "check-in", title: "Daily check-in", reward: "+20 coins", done: false },
  { id: "watch", title: "Watch 5 episodes", reward: "+50 coins", done: true },
  { id: "share", title: "Share a drama", reward: "+15 coins", done: false },
  { id: "ad", title: "Watch reward ad", reward: "+30 coins", done: false }
];
