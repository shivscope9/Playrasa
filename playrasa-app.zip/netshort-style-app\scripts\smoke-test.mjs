import { spawn } from "node:child_process";
import { setTimeout as wait } from "node:timers/promises";

const port = 4199;
const baseUrl = `http://localhost:${port}`;
const server = spawn(process.execPath, ["./server/server.mjs"], {
  cwd: new URL("..", import.meta.url),
  env: { ...process.env, PLAYRASA_PORT: String(port) },
  stdio: ["ignore", "pipe", "pipe"]
});

async function request(path, options) {
  const response = await fetch(`${baseUrl}${path}`, options);
  const text = await response.text();
  if (!response.ok) {
    throw new Error(`${response.status} ${text}`);
  }
  return text ? JSON.parse(text) : null;
}

async function waitForServer() {
  for (let index = 0; index < 30; index += 1) {
    try {
      await request("/api/dramas");
      return;
    } catch {
      await wait(150);
    }
  }
  throw new Error("Server did not start");
}

try {
  await waitForServer();
  const before = await request("/api/dramas");

  const created = await request("/api/admin/dramas", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      title: "Smoke Test Upload",
      subtitle: "Created by the PLAYRASA smoke test.",
      genre: "Test",
      episodeTitle: "Episode 1",
      videoUrl: "https://example.com/test.mp4",
      status: "published"
    })
  });

  const published = await request("/api/dramas");
  if (!published.some(item => item.id === created.id)) {
    throw new Error("Published upload was not visible to the app API");
  }

  await request(`/api/admin/dramas/${created.id}`, {
    method: "PATCH",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ status: "draft" })
  });

  const afterDraft = await request("/api/dramas");
  if (afterDraft.some(item => item.id === created.id)) {
    throw new Error("Draft upload leaked into app API");
  }

  await request(`/api/admin/dramas/${created.id}`, { method: "DELETE" });
  const afterDelete = await request("/api/admin/dramas");
  if (afterDelete.some(item => item.id === created.id)) {
    throw new Error("Deleted upload still exists");
  }

  console.log(`PASS: PLAYRASA API smoke test complete (${before.length} existing published upload(s)).`);
} finally {
  server.kill();
}
