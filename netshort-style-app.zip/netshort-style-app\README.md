# ShortDrama App

Original Expo/React Native starter for a short-drama streaming app inspired by the APK's visible feature set.

This is not copied APK source and does not include proprietary assets, keys, premium bypasses, or private endpoints.

## Features

- Home feed with featured dramas, categories, continue watching, and rankings
- Vertical episode player UI with like, collect, share, episode drawer, speed, and lock states
- Search/ranking page
- Rewards/check-in/task page
- VIP/coins/profile page
- Mock data layer ready to replace with a real API

## Run

```bash
npm install
npm start
```

Then press `a` for Android, `i` for iOS, or scan with Expo Go.

## Where to connect your backend

- Replace mock data in `src/data.ts`
- Add real API calls in `src/api.ts`
- Replace poster/video URLs with your licensed content URLs
- Add auth, payments, ads, analytics, and push notifications in their own service files
