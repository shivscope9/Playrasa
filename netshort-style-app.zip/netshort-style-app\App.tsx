import React, { useMemo, useState } from "react";
import {
  FlatList,
  Image,
  ImageBackground,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View
} from "react-native";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { Video, ResizeMode } from "expo-av";
import { LinearGradient } from "expo-linear-gradient";
import { NavigationContainer, RouteProp, useNavigation } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator, NativeStackNavigationProp } from "@react-navigation/native-stack";
import { colors, spacing } from "./src/theme";
import { categories, dramas, rewardTasks } from "./src/data";
import { Drama, RootStackParamList } from "./src/types";

type StackNav = NativeStackNavigationProp<RootStackParamList>;
type PlayerRoute = RouteProp<RootStackParamList, "Player">;

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tabs = createBottomTabNavigator();

function DramaTile({ item, onPress }: { item: Drama; onPress: () => void }) {
  return (
    <Pressable style={styles.tile} onPress={onPress}>
      <Image source={{ uri: item.poster }} style={styles.poster} />
      <Text style={styles.tileTitle} numberOfLines={2}>{item.title}</Text>
      <Text style={styles.tileMeta}>{item.score} • {item.views}</Text>
    </Pressable>
  );
}

function HomeScreen() {
  const navigation = useNavigation<StackNav>();
  const featured = dramas[0];

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <ImageBackground source={{ uri: featured.banner }} style={styles.hero}>
          <LinearGradient colors={["rgba(8,9,13,0.1)", colors.ink]} style={styles.heroOverlay}>
            <View style={styles.topBar}>
              <Text style={styles.logo}>ShortDrama</Text>
              <Pressable style={styles.iconButton}>
                <Ionicons name="search" color={colors.text} size={21} />
              </Pressable>
            </View>
            <Text style={styles.heroTitle}>{featured.title}</Text>
            <Text style={styles.heroSub} numberOfLines={2}>{featured.subtitle}</Text>
            <Pressable style={styles.primaryButton} onPress={() => navigation.navigate("Player", { dramaId: featured.id })}>
              <Ionicons name="play" color={colors.text} size={18} />
              <Text style={styles.primaryButtonText}>Play now</Text>
            </Pressable>
          </LinearGradient>
        </ImageBackground>

        <FlatList
          horizontal
          data={categories}
          keyExtractor={(item) => item}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.chipRow}
          renderItem={({ item, index }) => (
            <Text style={[styles.chip, index === 0 && styles.chipActive]}>{item}</Text>
          )}
        />

        <SectionTitle title="Trending now" action="More" />
        <FlatList
          horizontal
          data={dramas}
          keyExtractor={(item) => item.id}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.horizontalList}
          renderItem={({ item }) => <DramaTile item={item} onPress={() => navigation.navigate("Player", { dramaId: item.id })} />}
        />

        <SectionTitle title="Continue watching" />
        {dramas.map((item, index) => (
          <Pressable key={item.id} style={styles.continueRow} onPress={() => navigation.navigate("Player", { dramaId: item.id })}>
            <Image source={{ uri: item.poster }} style={styles.continuePoster} />
            <View style={styles.rowFill}>
              <Text style={styles.rowTitle}>{item.title}</Text>
              <Text style={styles.rowSub}>Episode {index + 3} • {item.genre}</Text>
              <View style={styles.progressTrack}>
                <View style={[styles.progressFill, { width: `${35 + index * 18}%` }]} />
              </View>
            </View>
            <Ionicons name="chevron-forward" color={colors.muted} size={20} />
          </Pressable>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

function DiscoverScreen() {
  const navigation = useNavigation<StackNav>();
  const [query, setQuery] = useState("");
  const filtered = useMemo(
    () => dramas.filter((drama) => drama.title.toLowerCase().includes(query.toLowerCase()) || drama.genre.toLowerCase().includes(query.toLowerCase())),
    [query]
  );

  return (
    <SafeAreaView style={styles.screen}>
      <View style={styles.padded}>
        <Text style={styles.pageTitle}>Discover</Text>
        <View style={styles.searchBox}>
          <Ionicons name="search" color={colors.muted} size={18} />
          <TextInput
            placeholder="Search dramas, genre, episode"
            placeholderTextColor={colors.muted}
            value={query}
            onChangeText={setQuery}
            style={styles.searchInput}
          />
        </View>
        <SectionTitle title="Ranking" />
        {filtered.map((item, index) => (
          <Pressable key={item.id} style={styles.rankRow} onPress={() => navigation.navigate("Player", { dramaId: item.id })}>
            <Text style={styles.rankNumber}>{index + 1}</Text>
            <Image source={{ uri: item.poster }} style={styles.rankPoster} />
            <View style={styles.rowFill}>
              <Text style={styles.rowTitle}>{item.title}</Text>
              <Text style={styles.rowSub}>{item.genre} • {item.views} views</Text>
            </View>
            <Text style={styles.score}>{item.score}</Text>
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  );
}

function RewardsScreen() {
  const [coins, setCoins] = useState(380);

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.padded}>
        <Text style={styles.pageTitle}>Rewards</Text>
        <LinearGradient colors={["#242938", "#191d29"]} style={styles.wallet}>
          <Text style={styles.walletLabel}>Coin balance</Text>
          <Text style={styles.walletAmount}>{coins}</Text>
          <Pressable style={styles.goldButton} onPress={() => setCoins(coins + 20)}>
            <Text style={styles.goldButtonText}>Check in</Text>
          </Pressable>
        </LinearGradient>
        <SectionTitle title="Daily tasks" />
        {rewardTasks.map((task) => (
          <View key={task.id} style={styles.taskRow}>
            <View style={[styles.taskIcon, task.done && styles.taskDone]}>
              <Ionicons name={task.done ? "checkmark" : "gift"} color={colors.text} size={18} />
            </View>
            <View style={styles.rowFill}>
              <Text style={styles.rowTitle}>{task.title}</Text>
              <Text style={styles.rowSub}>{task.reward}</Text>
            </View>
            <Pressable style={styles.smallButton}>
              <Text style={styles.smallButtonText}>{task.done ? "Done" : "Go"}</Text>
            </Pressable>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

function ProfileScreen() {
  const navigation = useNavigation<StackNav>();
  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.padded}>
        <Text style={styles.pageTitle}>Profile</Text>
        <LinearGradient colors={["#26212f", "#171b24"]} style={styles.profileCard}>
          <View style={styles.avatar}>
            <Ionicons name="person" color={colors.text} size={30} />
          </View>
          <View style={styles.rowFill}>
            <Text style={styles.rowTitle}>Guest User</Text>
            <Text style={styles.rowSub}>Sign in to sync watch history</Text>
          </View>
          <Pressable style={styles.smallButton}>
            <Text style={styles.smallButtonText}>Login</Text>
          </Pressable>
        </LinearGradient>
        <Pressable style={styles.vipBanner} onPress={() => navigation.navigate("Vip")}>
          <View>
            <Text style={styles.vipTitle}>VIP Membership</Text>
            <Text style={styles.rowSub}>Ad-free, HD, early access</Text>
          </View>
          <Ionicons name="chevron-forward" color={colors.gold} size={22} />
        </Pressable>
        {["My list", "Watch history", "Language", "Feedback", "Settings"].map((item) => (
          <Pressable key={item} style={styles.menuRow}>
            <Text style={styles.rowTitle}>{item}</Text>
            <Ionicons name="chevron-forward" color={colors.muted} size={19} />
          </Pressable>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

function PlayerScreen({ route, navigation }: { route: PlayerRoute; navigation: StackNav }) {
  const drama = dramas.find((item) => item.id === route.params.dramaId) ?? dramas[0];
  const [episodeIndex, setEpisodeIndex] = useState(0);
  const [liked, setLiked] = useState(false);
  const episode = drama.episodes[episodeIndex];

  return (
    <View style={styles.playerScreen}>
      <Video
        source={{ uri: episode.videoUrl ?? "" }}
        resizeMode={ResizeMode.COVER}
        shouldPlay
        isLooping
        style={StyleSheet.absoluteFill}
      />
      <LinearGradient colors={["rgba(0,0,0,0.45)", "transparent", "rgba(0,0,0,0.78)"]} style={StyleSheet.absoluteFill} />
      <SafeAreaView style={styles.playerChrome}>
        <View style={styles.playerTop}>
          <Pressable style={styles.iconButton} onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-back" color={colors.text} size={24} />
          </Pressable>
          <Text style={styles.playerTitle} numberOfLines={1}>{drama.title}</Text>
          <Pressable style={styles.iconButton}>
            <Ionicons name="ellipsis-horizontal" color={colors.text} size={22} />
          </Pressable>
        </View>
        <View style={styles.playerBottom}>
          <View style={styles.playerInfo}>
            <Text style={styles.episodeText}>EP {episode.number} / {drama.episodes.length}</Text>
            <Text style={styles.playerDramaTitle}>{episode.title}</Text>
            <Text style={styles.playerSubtitle} numberOfLines={2}>{drama.subtitle}</Text>
          </View>
          <View style={styles.actionRail}>
            <RailButton icon={liked ? "heart" : "heart-outline"} label="Like" active={liked} onPress={() => setLiked(!liked)} />
            <RailButton icon="bookmark-outline" label="Collect" />
            <RailButton icon="share-social-outline" label="Share" />
            <RailButton icon="speedometer-outline" label="Speed" />
          </View>
        </View>
        <FlatList
          horizontal
          data={drama.episodes}
          keyExtractor={(item) => item.id}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.episodeList}
          renderItem={({ item, index }) => (
            <Pressable
              style={[styles.episodePill, index === episodeIndex && styles.episodePillActive, item.locked && styles.episodePillLocked]}
              onPress={() => !item.locked && setEpisodeIndex(index)}
            >
              <Text style={styles.episodePillText}>{item.locked ? "Lock " : ""}{item.number}</Text>
            </Pressable>
          )}
        />
      </SafeAreaView>
    </View>
  );
}

function VipScreen() {
  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.padded}>
        <Text style={styles.pageTitle}>VIP</Text>
        <LinearGradient colors={["#3a2b16", "#171b24"]} style={styles.vipHero}>
          <Text style={styles.vipTitle}>Unlock every episode</Text>
          <Text style={styles.vipCopy}>Ad-free watching, HD playback, exclusive bonuses, and early releases.</Text>
        </LinearGradient>
        {["Weekly", "Monthly", "Yearly"].map((plan, index) => (
          <Pressable key={plan} style={[styles.planRow, index === 1 && styles.planActive]}>
            <View>
              <Text style={styles.rowTitle}>{plan} VIP</Text>
              <Text style={styles.rowSub}>{index === 1 ? "Best value" : "Flexible access"}</Text>
            </View>
            <Text style={styles.planPrice}>{["$2.99", "$7.99", "$49.99"][index]}</Text>
          </Pressable>
        ))}
        <Pressable style={styles.primaryButtonWide}>
          <Text style={styles.primaryButtonText}>Continue</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

function SectionTitle({ title, action }: { title: string; action?: string }) {
  return (
    <View style={styles.sectionTitle}>
      <Text style={styles.sectionText}>{title}</Text>
      {action ? <Text style={styles.sectionAction}>{action}</Text> : null}
    </View>
  );
}

function RailButton({ icon, label, active, onPress }: { icon: keyof typeof Ionicons.glyphMap; label: string; active?: boolean; onPress?: () => void }) {
  return (
    <Pressable style={styles.railButton} onPress={onPress}>
      <Ionicons name={icon} color={active ? colors.red : colors.text} size={29} />
      <Text style={styles.railLabel}>{label}</Text>
    </Pressable>
  );
}

function TabScreens() {
  return (
    <Tabs.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: colors.red,
        tabBarInactiveTintColor: colors.muted
      }}
    >
      <Tabs.Screen name="Home" component={HomeScreen} options={{ tabBarIcon: ({ color }) => <Ionicons name="home" color={color} size={22} /> }} />
      <Tabs.Screen name="Discover" component={DiscoverScreen} options={{ tabBarIcon: ({ color }) => <Ionicons name="compass" color={color} size={22} /> }} />
      <Tabs.Screen name="Rewards" component={RewardsScreen} options={{ tabBarIcon: ({ color }) => <MaterialCommunityIcons name="gift" color={color} size={22} /> }} />
      <Tabs.Screen name="Profile" component={ProfileScreen} options={{ tabBarIcon: ({ color }) => <Ionicons name="person" color={color} size={22} /> }} />
    </Tabs.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Tabs" component={TabScreens} />
        <Stack.Screen name="Player" component={PlayerScreen} />
        <Stack.Screen name="Vip" component={VipScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink },
  padded: { padding: spacing.md, paddingBottom: 110 },
  hero: { height: 430, backgroundColor: colors.panel },
  heroOverlay: { flex: 1, justifyContent: "flex-end", padding: spacing.md },
  topBar: { position: "absolute", top: 48, left: spacing.md, right: spacing.md, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  logo: { color: colors.text, fontSize: 23, fontWeight: "900" },
  heroTitle: { color: colors.text, fontSize: 38, fontWeight: "900", marginBottom: 8 },
  heroSub: { color: colors.muted, fontSize: 15, lineHeight: 21, marginBottom: 14 },
  primaryButton: { alignSelf: "flex-start", flexDirection: "row", gap: 8, alignItems: "center", backgroundColor: colors.red, paddingHorizontal: 18, paddingVertical: 11, borderRadius: 8 },
  primaryButtonWide: { alignItems: "center", backgroundColor: colors.red, paddingVertical: 14, borderRadius: 8, marginTop: spacing.md },
  primaryButtonText: { color: colors.text, fontSize: 15, fontWeight: "800" },
  iconButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: "rgba(0,0,0,0.35)", alignItems: "center", justifyContent: "center" },
  chipRow: { gap: 10, paddingHorizontal: spacing.md, paddingVertical: spacing.md },
  chip: { color: colors.muted, backgroundColor: colors.panel, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 18, overflow: "hidden", fontWeight: "700" },
  chipActive: { color: colors.text, backgroundColor: colors.red },
  sectionTitle: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: spacing.md, marginTop: spacing.sm, marginBottom: spacing.sm },
  sectionText: { color: colors.text, fontSize: 21, fontWeight: "900" },
  sectionAction: { color: colors.red, fontWeight: "800" },
  horizontalList: { paddingHorizontal: spacing.md, gap: 12, paddingBottom: spacing.md },
  tile: { width: 132 },
  poster: { width: 132, height: 184, borderRadius: 8, backgroundColor: colors.panel2 },
  tileTitle: { color: colors.text, fontWeight: "800", marginTop: 8, lineHeight: 18 },
  tileMeta: { color: colors.muted, marginTop: 4, fontSize: 12 },
  continueRow: { flexDirection: "row", alignItems: "center", gap: 12, marginHorizontal: spacing.md, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.border },
  continuePoster: { width: 58, height: 76, borderRadius: 6 },
  rowFill: { flex: 1 },
  rowTitle: { color: colors.text, fontWeight: "800", fontSize: 15 },
  rowSub: { color: colors.muted, marginTop: 4, fontSize: 13 },
  progressTrack: { height: 4, borderRadius: 2, backgroundColor: colors.panel2, marginTop: 10, overflow: "hidden" },
  progressFill: { height: 4, backgroundColor: colors.red },
  pageTitle: { color: colors.text, fontSize: 32, fontWeight: "900", marginBottom: spacing.md },
  searchBox: { height: 46, borderRadius: 8, backgroundColor: colors.panel, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 12, marginBottom: spacing.md },
  searchInput: { flex: 1, color: colors.text, fontSize: 15 },
  rankRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 10, borderBottomColor: colors.border, borderBottomWidth: 1 },
  rankNumber: { color: colors.gold, fontSize: 22, fontWeight: "900", width: 30 },
  rankPoster: { width: 54, height: 72, borderRadius: 6 },
  score: { color: colors.gold, fontWeight: "900" },
  wallet: { borderRadius: 8, padding: spacing.lg, marginBottom: spacing.md },
  walletLabel: { color: colors.muted, fontWeight: "700" },
  walletAmount: { color: colors.gold, fontSize: 44, fontWeight: "900", marginVertical: 8 },
  goldButton: { alignSelf: "flex-start", backgroundColor: colors.gold, paddingVertical: 10, paddingHorizontal: 16, borderRadius: 8 },
  goldButtonText: { color: colors.ink, fontWeight: "900" },
  taskRow: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.panel, borderRadius: 8, padding: 13, marginBottom: 10 },
  taskIcon: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.panel2, alignItems: "center", justifyContent: "center" },
  taskDone: { backgroundColor: colors.green },
  smallButton: { backgroundColor: colors.red, paddingVertical: 8, paddingHorizontal: 13, borderRadius: 7 },
  smallButtonText: { color: colors.text, fontWeight: "800" },
  profileCard: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 8, padding: spacing.md },
  avatar: { width: 54, height: 54, borderRadius: 27, backgroundColor: colors.panel2, alignItems: "center", justifyContent: "center" },
  vipBanner: { marginTop: spacing.md, borderRadius: 8, padding: spacing.md, backgroundColor: "#201a11", borderColor: "rgba(255,209,102,0.35)", borderWidth: 1, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  vipTitle: { color: colors.gold, fontSize: 19, fontWeight: "900" },
  vipCopy: { color: colors.muted, fontSize: 15, lineHeight: 22, marginTop: 8 },
  menuRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 18, borderBottomColor: colors.border, borderBottomWidth: 1 },
  playerScreen: { flex: 1, backgroundColor: "#000" },
  playerChrome: { flex: 1, justifyContent: "space-between" },
  playerTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: spacing.md },
  playerTitle: { color: colors.text, fontSize: 16, fontWeight: "900", maxWidth: "68%" },
  playerBottom: { flexDirection: "row", alignItems: "flex-end", padding: spacing.md, gap: spacing.md },
  playerInfo: { flex: 1 },
  episodeText: { color: colors.gold, fontWeight: "900", marginBottom: 8 },
  playerDramaTitle: { color: colors.text, fontSize: 22, fontWeight: "900" },
  playerSubtitle: { color: colors.muted, fontSize: 14, lineHeight: 20, marginTop: 6 },
  actionRail: { alignItems: "center", gap: 17 },
  railButton: { alignItems: "center", width: 58 },
  railLabel: { color: colors.text, fontSize: 11, marginTop: 4 },
  episodeList: { paddingHorizontal: spacing.md, gap: 8, paddingBottom: spacing.md },
  episodePill: { minWidth: 48, height: 38, borderRadius: 8, backgroundColor: "rgba(255,255,255,0.18)", alignItems: "center", justifyContent: "center", paddingHorizontal: 10 },
  episodePillActive: { backgroundColor: colors.red },
  episodePillLocked: { backgroundColor: "rgba(255,255,255,0.08)" },
  episodePillText: { color: colors.text, fontWeight: "800" },
  vipHero: { borderRadius: 8, padding: spacing.lg, marginBottom: spacing.md },
  planRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", backgroundColor: colors.panel, padding: spacing.md, borderRadius: 8, marginBottom: 10, borderWidth: 1, borderColor: colors.border },
  planActive: { borderColor: colors.gold },
  planPrice: { color: colors.gold, fontSize: 20, fontWeight: "900" },
  tabBar: { backgroundColor: colors.panel, borderTopColor: colors.border, height: 70, paddingBottom: 10, paddingTop: 8 }
});
