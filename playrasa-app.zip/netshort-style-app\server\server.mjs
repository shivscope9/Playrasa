import { createServer } from "node:http";
import { mkdir, readFile, rename, unlink, writeFile } from "node:fs/promises";
import { createWriteStream } from "node:fs";
import { basename, extname, join } from "node:path";
import { fileURLToPath } from "node:url";

const rootDir = fileURLToPath(new URL(".", import.meta.url));
const dataFile = join(rootDir, "data", "library.json");
const uploadsDir = join(rootDir, "uploads");
const port = Number(process.env.PLAYRASA_PORT || 4100);

await mkdir(join(rootDir, "data"), { recursive: true });
await mkdir(uploadsDir, { recursive: true });

async function readLibrary() {
  try {
    return JSON.parse(await readFile(dataFile, "utf8"));
  } catch {
    return [];
  }
}

async function writeLibrary(items) {
  await writeFile(dataFile, JSON.stringify(items, null, 2));
}

function sendJson(res, status, body) {
  const json = JSON.stringify(body);
  res.writeHead(status, {
    "content-type": "application/json",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,PATCH,DELETE,OPTIONS",
    "access-control-allow-headers": "content-type"
  });
  res.end(json);
}

function sendText(res, status, body, type = "text/plain") {
  res.writeHead(status, {
    "content-type": type,
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,PATCH,DELETE,OPTIONS",
    "access-control-allow-headers": "content-type"
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", chunk => chunks.push(chunk));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function parseMultipart(buffer, contentType) {
  const boundaryMatch = /boundary=(.+)$/i.exec(contentType || "");
  if (!boundaryMatch) return { fields: {}, files: {} };
  const boundary = `--${boundaryMatch[1]}`;
  const raw = buffer.toString("binary");
  const parts = raw.split(boundary).slice(1, -1);
  const fields = {};
  const files = {};

  for (const part of parts) {
    const trimmed = part.replace(/^\r\n/, "").replace(/\r\n$/, "");
    const divider = trimmed.indexOf("\r\n\r\n");
    if (divider === -1) continue;
    const header = trimmed.slice(0, divider);
    const body = trimmed.slice(divider + 4);
    const name = /name="([^"]+)"/.exec(header)?.[1];
    if (!name) continue;
    const filename = /filename="([^"]*)"/.exec(header)?.[1];
    if (filename) {
      files[name] = {
        filename,
        content: Buffer.from(body, "binary")
      };
    } else {
      fields[name] = Buffer.from(body, "binary").toString("utf8");
    }
  }

  return { fields, files };
}

function placeholderImage(title) {
  const label = encodeURIComponent(title || "PLAYRASA");
  return `https://dummyimage.com/720x1080/151821/ffffff.jpg&text=${label}`;
}

function publicUrl(req, path) {
  const host = req.headers.host || `localhost:${port}`;
  return `http://${host}${path}`;
}

async function saveUpload(req, file) {
  if (!file || !file.filename || file.content.length === 0) return "";
  const safeName = basename(file.filename).replace(/[^a-z0-9._-]/gi, "_");
  const extension = extname(safeName) || ".mp4";
  const filename = `${Date.now()}-${Math.random().toString(16).slice(2)}${extension}`;
  const tempPath = join(uploadsDir, `${filename}.tmp`);
  const finalPath = join(uploadsDir, filename);
  await new Promise((resolve, reject) => {
    const stream = createWriteStream(tempPath);
    stream.on("error", reject);
    stream.on("finish", resolve);
    stream.end(file.content);
  });
  await rename(tempPath, finalPath);
  return publicUrl(req, `/uploads/${filename}`);
}

async function handleCreate(req, res) {
  const contentType = req.headers["content-type"] || "";
  const body = await readBody(req);
  const { fields, files } = contentType.includes("multipart/form-data")
    ? parseMultipart(body, contentType)
    : { fields: JSON.parse(body.toString("utf8") || "{}"), files: {} };
  const title = String(fields.title || "").trim();
  const subtitle = String(fields.subtitle || "").trim();
  const genre = String(fields.genre || "Series").trim();
  const episodeTitle = String(fields.episodeTitle || "Episode 1").trim();
  const uploadedVideoUrl = await saveUpload(req, files.videoFile);
  const videoUrl = uploadedVideoUrl || String(fields.videoUrl || "").trim();

  if (!title || !subtitle || !videoUrl) {
    return sendJson(res, 400, { error: "Title, description, and video URL/file are required." });
  }

  const item = {
    id: `${Date.now()}-${title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}`,
    title,
    subtitle,
    genre,
    poster: String(fields.poster || "").trim() || placeholderImage(title),
    banner: String(fields.banner || "").trim() || String(fields.poster || "").trim() || placeholderImage(title),
    score: 10,
    views: "0",
    status: fields.status === "draft" ? "draft" : "published",
    episodes: [
      {
        id: `${Date.now()}-episode-1`,
        number: 1,
        title: episodeTitle,
        locked: false,
        duration: "0:00",
        videoUrl
      }
    ]
  };

  const library = await readLibrary();
  library.unshift(item);
  await writeLibrary(library);
  sendJson(res, 201, item);
}

async function handlePatch(req, res, id) {
  const body = JSON.parse((await readBody(req)).toString("utf8") || "{}");
  const library = await readLibrary();
  const item = library.find(entry => entry.id === id);
  if (!item) return sendJson(res, 404, { error: "Not found" });
  if (body.status === "published" || body.status === "draft") item.status = body.status;
  await writeLibrary(library);
  sendJson(res, 200, item);
}

async function handleDelete(res, id) {
  const library = await readLibrary();
  const next = library.filter(entry => entry.id !== id);
  if (next.length === library.length) return sendJson(res, 404, { error: "Not found" });
  await writeLibrary(next);
  sendJson(res, 200, { ok: true });
}

async function serveUpload(req, res, pathname) {
  const file = basename(pathname);
  try {
    const data = await readFile(join(uploadsDir, file));
    const ext = extname(file).toLowerCase();
    const type = ext === ".webm" ? "video/webm" : ext === ".mov" ? "video/quicktime" : "video/mp4";
    res.writeHead(200, { "content-type": type, "access-control-allow-origin": "*" });
    res.end(data);
  } catch {
    sendText(res, 404, "Not found");
  }
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url || "/", `http://${req.headers.host}`);
    const pathname = url.pathname;
    if (req.method === "OPTIONS") return sendText(res, 204, "");
    if (req.method === "GET" && (pathname === "/" || pathname === "/admin")) {
      return sendText(res, 200, await readFile(join(rootDir, "admin.html"), "utf8"), "text/html");
    }
    if (req.method === "GET" && pathname === "/api/dramas") {
      const library = await readLibrary();
      return sendJson(res, 200, library.filter(item => item.status === "published"));
    }
    if (req.method === "GET" && pathname === "/api/admin/dramas") {
      return sendJson(res, 200, await readLibrary());
    }
    if (req.method === "POST" && pathname === "/api/admin/dramas") {
      return handleCreate(req, res);
    }
    const match = /^\/api\/admin\/dramas\/(.+)$/.exec(pathname);
    if (match && req.method === "PATCH") return handlePatch(req, res, decodeURIComponent(match[1]));
    if (match && req.method === "DELETE") return handleDelete(res, decodeURIComponent(match[1]));
    if (req.method === "GET" && pathname.startsWith("/uploads/")) return serveUpload(req, res, pathname);
    sendText(res, 404, "Not found");
  } catch (error) {
    sendJson(res, 500, { error: error.message });
  }
});

server.listen(port, () => {
  console.log(`PLAYRASA admin: http://localhost:${port}/admin`);
});
