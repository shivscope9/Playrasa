import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Image,
  ImageBackground,
  Pressable,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View
} from "react-native";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { Video, ResizeMode } from "expo-av";
import { LinearGradient } from "expo-linear-gradient";
import { NavigationContainer, RouteProp, useFocusEffect, useNavigation } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator, NativeStackNavigationProp } from "@react-navigation/native-stack";
import { getDramas } from "./src/api";
import { brand } from "./src/brand";
import { categories, rewardTasks } from "./src/data";
import { colors, spacing } from "./src/theme";
import { Drama, RootStackParamList } from "./src/types";

type StackNav = NativeStackNavigationProp<RootStackParamList>;
type PlayerRoute = RouteProp<RootStackParamList, "Player">;

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tabs = createBottomTabNavigator();

function useLibrary() {
  const [items, setItems] = useState<Drama[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    const data = await getDramas();
    setItems(data);
    setLoading(false);
    setRefreshing(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      void load();
    }, [load])
  );

  const refresh = useCallback(() => {
    setRefreshing(true);
    void load();
  }, [load]);

  return { items, loading, refreshing, refresh };
}

function EmptyLibrary() {
  return (
    <View style={styles.emptyState}>
      <View style={styles.logoMark}>
        <Text style={styles.logoLetter}>P</Text>
      </View>
      <Text style={styles.emptyTitle}>No uploaded content yet</Text>
      <Text style={styles.emptyCopy}>
        PLAYRASA only shows videos that you upload and publish from the admin panel.
      </Text>
      <Text style={styles.adminLink}>{brand.adminUrl}</Text>
    </View>
  );
}

function BrandHeader() {
  return (
    <View style={styles.brandHeader}>
      <View>
        <Text style={styles.logo}>{brand.name}</Text>
        <Text style={styles.tagline}>{brand.tagline}</Text>
      </View>
      <View style={styles.logoMarkSmall}>
        <Text style={styles.logoLetterSmall}>P</Text>
      </View>
    </View>
  );
}

function HomeScreen() {
  const navigation = useNavigation<StackNav>();
  const { items, loading, refreshing, refresh } = useLibrary();
  const featured = items[0];

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView
        refreshControl={<RefreshControl tintColor={colors.red} refreshing={refreshing} onRefresh={refresh} />}
        showsVerticalScrollIndicator={false}
      >
        <BrandHeader />
        {!featured ? (
          <EmptyLibrary />
        ) : (
          <>
            <ImageBackground source={{ uri: featured.banner || featured.poster }} style={styles.hero}>
              <LinearGradient colors={["rgba(8,9,13,0.05)", colors.ink]} style={styles.heroOverlay}>
                <Text style={styles.heroTitle}>{featured.title}</Text>
                <Text style={styles.heroSub} numberOfLines={2}>{featured.subtitle}</Text>
                <Pressable style={styles.primaryButton} onPress={() => navigation.navigate("Player", { dramaId: featured.id })}>
                  <Ionicons name="play" color={colors.text} size={18} />
                  <Text style={styles.primaryButtonText}>Play uploaded video</Text>
                </Pressable>
              </LinearGradient>
            </ImageBackground>
            <FlatList
              horizontal
              data={categories}
              keyExtractor={(item) => item}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.chipRow}
              renderItem={({ item, index }) => <Text style={[styles.chip, index === 0 && styles.chipActive]}>{item}</Text>}
            />
            <SectionTitle title="Your uploads" action={`${items.length} published`} />
            <FlatList
              horizontal
              data={items}
              keyExtractor={(item) => item.id}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.horizontalList}
              renderItem={({ item }) => <DramaTile item={item} onPress={() => navigation.navigate("Player", { dramaId: item.id })} />}
            />
            <SectionTitle title="Continue playing" />
            {items.map((item) => (
              <Pressable key={item.id} style={styles.continueRow} onPress={() => navigation.navigate("Player", { dramaId: item.id })}>
                <Image source={{ uri: item.poster }} style={styles.continuePoster} />
                <View style={styles.rowFill}>
                  <Text style={styles.rowTitle}>{item.title}</Text>
                  <Text style={styles.rowSub}>{item.episodes.length} uploaded episodes - {item.genre}</Text>
                  <View style={styles.progressTrack}>
                    <View style={styles.progressFill} />
                  </View>
                </View>
                <Ionicons name="chevron-forward" color={colors.muted} size={20} />
              </Pressable>
            ))}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

function DiscoverScreen() {
  const navigation = useNavigation<StackNav>();
  const { items, loading, refreshing, refresh } = useLibrary();
  const [query, setQuery] = useState("");
  const filtered = useMemo(
    () => items.filter((drama) => `${drama.title} ${drama.genre} ${drama.subtitle}`.toLowerCase().includes(query.toLowerCase())),
    [items, query]
  );

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView
        contentContainerStyle={styles.padded}
        refreshControl={<RefreshControl tintColor={colors.red} refreshing={refreshing} onRefresh={refresh} />}
      >
        <Text style={styles.pageTitle}>Library</Text>
        <View style={styles.searchBox}>
          <Ionicons name="search" color={colors.muted} size={18} />
          <TextInput
            placeholder="Search your uploads"
            placeholderTextColor={colors.muted}
            value={query}
            onChangeText={setQuery}
            style={styles.searchInput}
          />
        </View>
        {filtered.length === 0 ? (
          <EmptyLibrary />
        ) : (
          filtered.map((item, index) => (
            <Pressable key={item.id} style={styles.rankRow} onPress={() => navigation.navigate("Player", { dramaId: item.id })}>
              <Text style={styles.rankNumber}>{index + 1}</Text>
              <Image source={{ uri: item.poster }} style={styles.rankPoster} />
              <View style={styles.rowFill}>
                <Text style={styles.rowTitle}>{item.title}</Text>
                <Text style={styles.rowSub}>{item.genre} - {item.episodes.length} episodes</Text>
              </View>
              <Text style={styles.score}>{item.score}</Text>
            </Pressable>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

function RewardsScreen() {
  const [coins, setCoins] = useState(0);

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.padded}>
        <Text style={styles.pageTitle}>Access</Text>
        <LinearGradient colors={["#252836", "#151821"]} style={styles.wallet}>
          <Text style={styles.walletLabel}>Owner controls</Text>
          <Text style={styles.walletAmount}>{coins}</Text>
          <Text style={styles.rowSub}>Coins start at zero. Connect payments or rewards only when you want monetization.</Text>
          <Pressable style={styles.goldButton} onPress={() => setCoins(coins + 20)}>
            <Text style={styles.goldButtonText}>Test reward</Text>
          </Pressable>
        </LinearGradient>
        <SectionTitle title="Test tasks" />
        {rewardTasks.map((task) => (
          <View key={task.id} style={styles.taskRow}>
            <View style={[styles.taskIcon, task.done && styles.taskDone]}>
              <Ionicons name={task.done ? "checkmark" : "gift"} color={colors.text} size={18} />
            </View>
            <View style={styles.rowFill}>
              <Text style={styles.rowTitle}>{task.title}</Text>
              <Text style={styles.rowSub}>{task.reward}</Text>
            </View>
            <Pressable style={styles.smallButton}>
              <Text style={styles.smallButtonText}>{task.done ? "Done" : "Go"}</Text>
            </Pressable>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

function ProfileScreen() {
  const navigation = useNavigation<StackNav>();

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.padded}>
        <Text style={styles.pageTitle}>Owner</Text>
        <LinearGradient colors={["#202332", "#141720"]} style={styles.profileCard}>
          <View style={styles.avatar}>
            <Text style={styles.logoLetterSmall}>P</Text>
          </View>
          <View style={styles.rowFill}>
            <Text style={styles.rowTitle}>PLAYRASA Admin</Text>
            <Text style={styles.rowSub}>Manage uploads at {brand.adminUrl}</Text>
          </View>
        </LinearGradient>
        <Pressable style={styles.vipBanner} onPress={() => navigation.navigate("Vip")}>
          <View>
            <Text style={styles.vipTitle}>Admin Panel</Text>
            <Text style={styles.rowSub}>Upload, publish, unpublish, and delete content</Text>
          </View>
          <Ionicons name="chevron-forward" color={colors.gold} size={22} />
        </Pressable>
        {["My uploads only", "No old APK content", "Published videos only", "Custom PLAYRASA interface"].map((item) => (
          <View key={item} style={styles.menuRow}>
            <Text style={styles.rowTitle}>{item}</Text>
            <Ionicons name="checkmark-circle" color={colors.green} size={20} />
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

function PlayerScreen({ route, navigation }: { route: PlayerRoute; navigation: StackNav }) {
  const [library, setLibrary] = useState<Drama[]>([]);
  const [loading, setLoading] = useState(true);
  const [episodeIndex, setEpisodeIndex] = useState(0);
  const [liked, setLiked] = useState(false);

  useEffect(() => {
    getDramas().then((items) => {
      setLibrary(items);
      setLoading(false);
    });
  }, []);

  const drama = library.find((item) => item.id === route.params.dramaId);
  const episode = drama?.episodes[episodeIndex];

  if (loading) {
    return <LoadingScreen />;
  }

  if (!drama || !episode || !episode.videoUrl) {
    return (
      <SafeAreaView style={styles.screen}>
        <Pressable style={styles.backRow} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" color={colors.text} size={24} />
          <Text style={styles.rowTitle}>Back</Text>
        </Pressable>
        <EmptyLibrary />
      </SafeAreaView>
    );
  }

  return (
    <View style={styles.playerScreen}>
      <Video source={{ uri: episode.videoUrl }} resizeMode={ResizeMode.COVER} shouldPlay isLooping style={StyleSheet.absoluteFill} />
      <LinearGradient colors={["rgba(0,0,0,0.48)", "transparent", "rgba(0,0,0,0.82)"]} style={StyleSheet.absoluteFill} />
      <SafeAreaView style={styles.playerChrome}>
        <View style={styles.playerTop}>
          <Pressable style={styles.iconButton} onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-back" color={colors.text} size={24} />
          </Pressable>
          <Text style={styles.playerTitle} numberOfLines={1}>{drama.title}</Text>
          <View style={styles.iconButton}>
            <Text style={styles.logoLetterTiny}>P</Text>
          </View>
        </View>
        <View style={styles.playerBottom}>
          <View style={styles.playerInfo}>
            <Text style={styles.episodeText}>EP {episode.number} / {drama.episodes.length}</Text>
            <Text style={styles.playerDramaTitle}>{episode.title}</Text>
            <Text style={styles.playerSubtitle} numberOfLines={2}>{drama.subtitle}</Text>
          </View>
          <View style={styles.actionRail}>
            <RailButton icon={liked ? "heart" : "heart-outline"} label="Like" active={liked} onPress={() => setLiked(!liked)} />
            <RailButton icon="bookmark-outline" label="Save" />
            <RailButton icon="share-social-outline" label="Share" />
          </View>
        </View>
        <FlatList
          horizontal
          data={drama.episodes}
          keyExtractor={(item) => item.id}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.episodeList}
          renderItem={({ item, index }) => (
            <Pressable style={[styles.episodePill, index === episodeIndex && styles.episodePillActive]} onPress={() => setEpisodeIndex(index)}>
              <Text style={styles.episodePillText}>{item.number}</Text>
            </Pressable>
          )}
        />
      </SafeAreaView>
    </View>
  );
}

function VipScreen() {
  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.padded}>
        <Text style={styles.pageTitle}>Admin Control</Text>
        <LinearGradient colors={["#32251a", "#151821"]} style={styles.vipHero}>
          <Text style={styles.vipTitle}>PLAYRASA is controlled by your uploads</Text>
          <Text style={styles.vipCopy}>
            The mobile app has no old APK catalog. Publish content in the admin panel and the app will refresh from your API.
          </Text>
        </LinearGradient>
        {["Create series", "Upload episodes", "Publish/unpublish", "Delete uploads"].map((item) => (
          <View key={item} style={styles.planRow}>
            <Text style={styles.rowTitle}>{item}</Text>
            <Ionicons name="checkmark-circle" color={colors.green} size={22} />
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

function DramaTile({ item, onPress }: { item: Drama; onPress: () => void }) {
  return (
    <Pressable style={styles.tile} onPress={onPress}>
      <Image source={{ uri: item.poster }} style={styles.poster} />
      <Text style={styles.tileTitle} numberOfLines={2}>{item.title}</Text>
      <Text style={styles.tileMeta}>{item.episodes.length} episodes</Text>
    </Pressable>
  );
}

function LoadingScreen() {
  return (
    <SafeAreaView style={styles.screenCenter}>
      <ActivityIndicator color={colors.red} />
      <Text style={styles.loadingText}>Loading PLAYRASA</Text>
    </SafeAreaView>
  );
}

function SectionTitle({ title, action }: { title: string; action?: string }) {
  return (
    <View style={styles.sectionTitle}>
      <Text style={styles.sectionText}>{title}</Text>
      {action ? <Text style={styles.sectionAction}>{action}</Text> : null}
    </View>
  );
}

function RailButton({ icon, label, active, onPress }: { icon: keyof typeof Ionicons.glyphMap; label: string; active?: boolean; onPress?: () => void }) {
  return (
    <Pressable style={styles.railButton} onPress={onPress}>
      <Ionicons name={icon} color={active ? colors.red : colors.text} size={29} />
      <Text style={styles.railLabel}>{label}</Text>
    </Pressable>
  );
}

function TabScreens() {
  return (
    <Tabs.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: colors.red,
        tabBarInactiveTintColor: colors.muted
      }}
    >
      <Tabs.Screen name="Home" component={HomeScreen} options={{ tabBarIcon: ({ color }) => <Ionicons name="home" color={color} size={22} /> }} />
      <Tabs.Screen name="Library" component={DiscoverScreen} options={{ tabBarIcon: ({ color }) => <Ionicons name="albums" color={color} size={22} /> }} />
      <Tabs.Screen name="Access" component={RewardsScreen} options={{ tabBarIcon: ({ color }) => <MaterialCommunityIcons name="shield-key" color={color} size={22} /> }} />
      <Tabs.Screen name="Owner" component={ProfileScreen} options={{ tabBarIcon: ({ color }) => <Ionicons name="person" color={color} size={22} /> }} />
    </Tabs.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Tabs" component={TabScreens} />
        <Stack.Screen name="Player" component={PlayerScreen} />
        <Stack.Screen name="Vip" component={VipScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink },
  screenCenter: { flex: 1, backgroundColor: colors.ink, alignItems: "center", justifyContent: "center", gap: 12 },
  loadingText: { color: colors.muted },
  padded: { padding: spacing.md, paddingBottom: 110 },
  brandHeader: { paddingHorizontal: spacing.md, paddingTop: 10, paddingBottom: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  logo: { color: colors.text, fontSize: 30, fontWeight: "900", letterSpacing: 0 },
  tagline: { color: colors.muted, marginTop: 2 },
  logoMark: { width: 86, height: 86, borderRadius: 22, backgroundColor: colors.red, alignItems: "center", justifyContent: "center", marginBottom: 18 },
  logoMarkSmall: { width: 48, height: 48, borderRadius: 14, backgroundColor: colors.red, alignItems: "center", justifyContent: "center" },
  logoLetter: { color: colors.text, fontSize: 52, fontWeight: "900" },
  logoLetterSmall: { color: colors.text, fontSize: 24, fontWeight: "900" },
  logoLetterTiny: { color: colors.text, fontSize: 17, fontWeight: "900" },
  emptyState: { alignItems: "center", justifyContent: "center", padding: spacing.xl, minHeight: 360 },
  emptyTitle: { color: colors.text, fontSize: 24, fontWeight: "900", textAlign: "center" },
  emptyCopy: { color: colors.muted, textAlign: "center", lineHeight: 21, marginTop: 10 },
  adminLink: { color: colors.cyan, fontWeight: "800", marginTop: 16 },
  hero: { height: 420, backgroundColor: colors.panel },
  heroOverlay: { flex: 1, justifyContent: "flex-end", padding: spacing.md },
  heroTitle: { color: colors.text, fontSize: 36, fontWeight: "900", marginBottom: 8 },
  heroSub: { color: colors.muted, fontSize: 15, lineHeight: 21, marginBottom: 14 },
  primaryButton: { alignSelf: "flex-start", flexDirection: "row", gap: 8, alignItems: "center", backgroundColor: colors.red, paddingHorizontal: 18, paddingVertical: 11, borderRadius: 8 },
  primaryButtonText: { color: colors.text, fontSize: 15, fontWeight: "800" },
  iconButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: "rgba(0,0,0,0.35)", alignItems: "center", justifyContent: "center" },
  chipRow: { gap: 10, paddingHorizontal: spacing.md, paddingVertical: spacing.md },
  chip: { color: colors.muted, backgroundColor: colors.panel, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 18, overflow: "hidden", fontWeight: "700" },
  chipActive: { color: colors.text, backgroundColor: colors.red },
  sectionTitle: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: spacing.md, marginTop: spacing.sm, marginBottom: spacing.sm },
  sectionText: { color: colors.text, fontSize: 21, fontWeight: "900" },
  sectionAction: { color: colors.red, fontWeight: "800" },
  horizontalList: { paddingHorizontal: spacing.md, gap: 12, paddingBottom: spacing.md },
  tile: { width: 132 },
  poster: { width: 132, height: 184, borderRadius: 8, backgroundColor: colors.panel2 },
  tileTitle: { color: colors.text, fontWeight: "800", marginTop: 8, lineHeight: 18 },
  tileMeta: { color: colors.muted, marginTop: 4, fontSize: 12 },
  continueRow: { flexDirection: "row", alignItems: "center", gap: 12, marginHorizontal: spacing.md, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.border },
  continuePoster: { width: 58, height: 76, borderRadius: 6 },
  rowFill: { flex: 1 },
  rowTitle: { color: colors.text, fontWeight: "800", fontSize: 15 },
  rowSub: { color: colors.muted, marginTop: 4, fontSize: 13 },
  progressTrack: { height: 4, borderRadius: 2, backgroundColor: colors.panel2, marginTop: 10, overflow: "hidden" },
  progressFill: { height: 4, width: "40%", backgroundColor: colors.red },
  pageTitle: { color: colors.text, fontSize: 32, fontWeight: "900", marginBottom: spacing.md },
  searchBox: { height: 46, borderRadius: 8, backgroundColor: colors.panel, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 12, marginBottom: spacing.md },
  searchInput: { flex: 1, color: colors.text, fontSize: 15 },
  rankRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 10, borderBottomColor: colors.border, borderBottomWidth: 1 },
  rankNumber: { color: colors.gold, fontSize: 22, fontWeight: "900", width: 30 },
  rankPoster: { width: 54, height: 72, borderRadius: 6 },
  score: { color: colors.gold, fontWeight: "900" },
  wallet: { borderRadius: 8, padding: spacing.lg, marginBottom: spacing.md },
  walletLabel: { color: colors.muted, fontWeight: "700" },
  walletAmount: { color: colors.gold, fontSize: 44, fontWeight: "900", marginVertical: 8 },
  goldButton: { alignSelf: "flex-start", backgroundColor: colors.gold, paddingVertical: 10, paddingHorizontal: 16, borderRadius: 8, marginTop: 12 },
  goldButtonText: { color: colors.ink, fontWeight: "900" },
  taskRow: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.panel, borderRadius: 8, padding: 13, marginBottom: 10 },
  taskIcon: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.panel2, alignItems: "center", justifyContent: "center" },
  taskDone: { backgroundColor: colors.green },
  smallButton: { backgroundColor: colors.red, paddingVertical: 8, paddingHorizontal: 13, borderRadius: 7 },
  smallButtonText: { color: colors.text, fontWeight: "800" },
  profileCard: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 8, padding: spacing.md },
  avatar: { width: 54, height: 54, borderRadius: 27, backgroundColor: colors.red, alignItems: "center", justifyContent: "center" },
  vipBanner: { marginTop: spacing.md, borderRadius: 8, padding: spacing.md, backgroundColor: "#201a11", borderColor: "rgba(255,209,102,0.35)", borderWidth: 1, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  vipTitle: { color: colors.gold, fontSize: 19, fontWeight: "900" },
  vipCopy: { color: colors.muted, fontSize: 15, lineHeight: 22, marginTop: 8 },
  menuRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 18, borderBottomColor: colors.border, borderBottomWidth: 1 },
  backRow: { flexDirection: "row", alignItems: "center", gap: 8, padding: spacing.md },
  playerScreen: { flex: 1, backgroundColor: "#000" },
  playerChrome: { flex: 1, justifyContent: "space-between" },
  playerTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: spacing.md },
  playerTitle: { color: colors.text, fontSize: 16, fontWeight: "900", maxWidth: "68%" },
  playerBottom: { flexDirection: "row", alignItems: "flex-end", padding: spacing.md, gap: spacing.md },
  playerInfo: { flex: 1 },
  episodeText: { color: colors.gold, fontWeight: "900", marginBottom: 8 },
  playerDramaTitle: { color: colors.text, fontSize: 22, fontWeight: "900" },
  playerSubtitle: { color: colors.muted, fontSize: 14, lineHeight: 20, marginTop: 6 },
  actionRail: { alignItems: "center", gap: 17 },
  railButton: { alignItems: "center", width: 58 },
  railLabel: { color: colors.text, fontSize: 11, marginTop: 4 },
  episodeList: { paddingHorizontal: spacing.md, gap: 8, paddingBottom: spacing.md },
  episodePill: { minWidth: 48, height: 38, borderRadius: 8, backgroundColor: "rgba(255,255,255,0.18)", alignItems: "center", justifyContent: "center", paddingHorizontal: 10 },
  episodePillActive: { backgroundColor: colors.red },
  episodePillText: { color: colors.text, fontWeight: "800" },
  vipHero: { borderRadius: 8, padding: spacing.lg, marginBottom: spacing.md },
  planRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", backgroundColor: colors.panel, padding: spacing.md, borderRadius: 8, marginBottom: 10, borderWidth: 1, borderColor: colors.border },
  tabBar: { backgroundColor: colors.panel, borderTopColor: colors.border, height: 70, paddingBottom: 10, paddingTop: 8 }
});
