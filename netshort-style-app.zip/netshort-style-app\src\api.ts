import { dramas, rewardTasks } from "./data";

export async function getDramas() {
  return dramas;
}

export async function getDrama(id: string) {
  return dramas.find((drama) => drama.id === id) ?? dramas[0];
}

export async function getRewards() {
  return rewardTasks;
}
